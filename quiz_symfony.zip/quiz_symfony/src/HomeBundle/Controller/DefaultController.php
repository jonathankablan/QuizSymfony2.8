<?php

namespace HomeBundle\Controller;

use HomeBundle\Entity\User;
use HomeBundle\Entity\Theme;
use HomeBundle\Entity\Question;
use HomeBundle\Entity\Notes;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Session\Session;

class DefaultController extends Controller
{

    /**
     * @Route("/", name="home")
     */
    public function indexAction()
    {
        $con = $this->getDoctrine()->getManager();
        $themes = $con->getRepository('HomeBundle:Theme')->findAll();

        $session = new session();
        return $this->render('HomeBundle:Default:index.html.twig', ["themes"=>$themes]);
    }


    /**
     * @Route("/connexion", name="connexion")
     */
    public function connexionAction(Request $request)
    {
        $con = $this->getDoctrine()->getManager();
        $session = new session();

        $themes = $con->getRepository('HomeBundle:Theme')->findAll();

        if ($request->isMethod("POST")) {

                $email    = $request->get("email");
                $password = $request->get("password");

                $reponse = $con->getRepository('HomeBundle:User')->findBy(['email'=>$email, 'password'=>$password]);

            if ($reponse) {

                $user_connect = $reponse[0]->getId();

                $session->set('email', $email);

                // Id de l'user connect en session pour gere ces notes en base de donnée
                $session->set('user_connect', $user_connect);

                $send_mail =$session->get('email');

                return $this->render('HomeBundle:Default:index.html.twig' , ['send_mail'=>$send_mail,"themes"=>$themes]);

            }else{
            
                return $this->render('HomeBundle:Default:connexion.html.twig');
            }

        }else{

            return $this->render('HomeBundle:Default:connexion.html.twig');
        }
        return $this->render('HomeBundle:Default:connexion.html.twig');
    }


    /**
     * @Route("/inscription", name="inscription")
     */
    public function inscriptionAction(Request $request)
    {
        $con = $this->getDoctrine()->getManager();
        $session = new session();


        /*
         * STEP 1 : Envoie de Mail
         * Configurer le fichier parameters.yml ET config.yml
         */

        /*$message = \Swift_Message::newInstance()
            ->setSubject('Hello Email')
            ->setFrom('jonathan.kablan@gmail.com')
            ->setTo('jonathan.kablan@gmail.com')
            ->setCharset('utf-8')
            ->setContentType('text/html')
            ->setBody('premier test reussis');

        $rep = $this->get('mailer')->send($message);*/

        // FIN DE L'Envoie de mail



        if ($request->isMethod("POST")) {

                $name     = $request->get("name");
                $email    = $request->get("email");
                $password = $request->get("password");

            $reponse = $con->getRepository('HomeBundle:User')->findBy(['email'=>$email]);

            if ($reponse) {
                
                $session->getFlashBag()->add('error', 'Cet est Email déjà Utilisé !');
                return $this->render('HomeBundle:Default:inscription.html.twig');

            }else{
            
                $user = new User();
                $user->setName($name);
                $user->setEmail($email);
                $user->setPassword($password);
                $user->setCreated();
                

                $con->persist($user);
                $confirm = $con->flush();



                if (!$confirm) {
                    $session->getFlashBag()->add('success', 'Inscription Valide');
                    return $this->render('HomeBundle:Default:inscription.html.twig');
                }else{
                    $session->getFlashBag()->add('error', 'Inscription echoué');
                    return $this->render('HomeBundle:Default:inscription.html.twig');
                }
            }

        }else{

            return $this->render('HomeBundle:Default:inscription.html.twig');
        }
        return $this->render('HomeBundle:Default:inscription.html.twig');
    }


    /**
     * @Route("/creatquiz", name="creatquiz")
     */
    public function creatquizAction(Request $request)
    {
        $session = new session();
        $con = $this->getDoctrine()->getManager();

        if ($request->isMethod("POST")) {

            $name = $request->get("name");

            $reponse = $con->getRepository('HomeBundle:Theme')->findBy(['name'=>$name]);


            if ($reponse) {

                $session->getFlashBag()->add('error', 'Cet Theme existe déjà !');
                return $this->render('HomeBundle:Default:creat.html.twig');
            }else{

            $theme = new Theme();
            $theme->setName($name);
            $theme->setIdauteur($session->get('user_connect'));

            $con->persist($theme);
            $confirm = $con->flush();

                if (!$confirm) {
                    $session->getFlashBag()->add('success', 'Theme est créer');
                    return $this->render('HomeBundle:Default:creat.html.twig');
                }else{
                    $session->getFlashBag()->add('error', 'Echoué de creation');
                    return $this->render('HomeBundle:Default:creat.html.twig');
                } 
            }

        }

        return $this->render('HomeBundle:Default:creat.html.twig');
    }



    /**
     * @Route("/questionquiz", name="questionquiz")
     */
    public function questionquizAction(Request $request)
    {
        $session = new session();
        $con = $this->getDoctrine()->getManager();
        $themes = $con->getRepository('HomeBundle:Theme')->findAll();

        if ($request->isMethod("POST")) {

            $idtheme  = $request->get("idtheme");
            $question = $request->get("question");
            $reponse  = $request->get("reponse");

            $quest = $this->getDoctrine()->getManager();
            $ask = new Question();
            $ask->setIdtheme($idtheme);
            $ask->setQuestion($question);
            $ask->setIdreponse($reponse);

            $quest->persist($ask);
            $confirm = $quest->flush();

            $themes = $con->getRepository('HomeBundle:Theme')->findAll();
                if (!$confirm) {
                    $session->getFlashBag()->add('success', 'Question est créer', ["themes"=>$themes]);
                    return $this->render('HomeBundle:Default:question.html.twig', ["themes"=>$themes]);
                }else{
                    $session->getFlashBag()->add('error', 'Echec Questionnaire', ["themes"=>$themes]);
                    return $this->render('HomeBundle:Default:question.html.twig', ["themes"=>$themes]);
                }

        }
        
        return $this->render('HomeBundle:Default:question.html.twig', ["themes"=>$themes]);
    }


    /**
     * @Route("/quiz/{item}", name="quiz", requirements={"item": "\d+"})
     * @Method({"GET","POST"})
     */
    public function quizAction(Request $request, $item)
    {
        $note = 0;
        $session = new session();

        $con = $this->getDoctrine()->getManager();
        $quiz = $con->getRepository('HomeBundle:Question')->findBy(
                ["idtheme"=>$item,]
            );

        if ($request->isMethod("POST") == "POST") {
               $note = 0;
               $rep = 0;

            foreach ($quiz as $value) {
               $data = $value;

               $nbr = count($request->request);

               if ($data->getIdreponse() == $request->GET("rep".$data->getId()) ) {
                   $rep++;
               }

            }

            if ($rep == 0) {
                $note = 0;
            } else {
                $note = ceil(($rep * 100) / $nbr);
            
            }


            if (!is_null($session->get('user_connect')) and !empty($session->get('user_connect')) ) {
                
                $user = new Notes();
                $user->setIduser($session->get('user_connect'));
                $user->setNote($note);
                $user->setIdtheme($item);
                $user->setCreated();
                
                $con->persist($user);
                $con->flush();
                $session->getFlashBag()->add('note_send', 'Votre Note est Enregistré.');
            }

        }

        return $this->render('HomeBundle:Default:quiz.html.twig', ["quiz"=>$quiz, "item"=>$item, "note"=>$note]);
    }


    /**
     * @Route("/notes", name="notes")
     */
    public function notesAction()
    {
        $session = new session();

        $em = $this->getDoctrine()->getManager();
        $ids = $session->get('user_connect');
        $query = $em->getRepository('HomeBundle:Notes')->findBy(
                ["iduser"=>$ids,]
            );

        return $this->render('HomeBundle:Default:notes.html.twig', ['notes'=>$query]);
    }


    /**
     * @Route("/noteall", name="noteall")
     */
    public function noteallAction()
    {
        $session = new session();

        $em = $this->getDoctrine()->getManager();
        $ids = $session->get('user_connect');
        $query = $em->getRepository('HomeBundle:Notes')->findAll();

        return $this->render('HomeBundle:Default:noteall.html.twig', ['notes'=>$query]);
    }


    /**
     * @Route("/profil", name="profil")
     */
    public function profilAction(Request $req)
    {
        $session = new session();
        $em = $this->getDoctrine()->getManager();
        $ids = $session->get('user_connect');

        $query = $em->getRepository('HomeBundle:User')->findBy(
                ["id"=>$ids,]
            );


        $name = $req->get('name');
        $email = $req->get('email');
        $password = $req->get('password');

        $prod = $em->getRepository('HomeBundle:User')->find($ids);

        if ($req->isMethod("post")) {

            $prod->setName($name);
            $prod->setEmail($email);
            $prod->setPassword($password);
            $em->flush();

            $session->getFlashBag()->add('success', 'Profil Update');
        }

        return $this->render('HomeBundle:Default:edit.html.twig', ["profil"=>$query]);
    }


    /**
     * @Route("/logout", name="logout")
     */
    public function logoutAction()
    {
        $session = new session();
        $session->remove('email');
        $session->remove('user_connect');

        $con = $this->getDoctrine()->getManager();
        $themes = $con->getRepository('HomeBundle:Theme')->findAll();

        return $this->render('HomeBundle:Default:index.html.twig', ["themes"=>$themes]);
    }
}