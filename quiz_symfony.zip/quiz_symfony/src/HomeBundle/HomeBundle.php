<?php

namespace HomeBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class HomeBundle extends Bundle
{
}
