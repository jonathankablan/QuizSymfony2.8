<?php

/* HomeBundle::base.html.twig */
class __TwigTemplate_8a310eaf80a74cf8b7f138425b9e081a591c6cb5807a4b3f0da1047e7fc1e104 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'prfil' => array($this, 'block_prfil'),
            'menu' => array($this, 'block_menu'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6b5a8102dacab3fa5e1383f0338bda63a2b56edc70895fb77ed50c7700888a1f = $this->env->getExtension("native_profiler");
        $__internal_6b5a8102dacab3fa5e1383f0338bda63a2b56edc70895fb77ed50c7700888a1f->enter($__internal_6b5a8102dacab3fa5e1383f0338bda63a2b56edc70895fb77ed50c7700888a1f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "HomeBundle::base.html.twig"));

        // line 1
        echo "<!DOCTYPE HTML>
<html>
\t<head>
\t\t<title>QUIZ HOME</title>
\t\t<meta charset=\"utf-8\" />
\t\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />
\t\t<!--[if lte IE 8]><script src=\"assets/js/ie/html5shiv.js\"></script><![endif]-->
\t\t<link rel=\"stylesheet\" href=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/css/main.css"), "html", null, true);
        echo "\" />
\t\t<!--[if lte IE 8]><link rel=\"stylesheet\" href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/css/ie8.css"), "html", null, true);
        echo "\" /><![endif]-->
\t\t<!--[if lte IE 9]><link rel=\"stylesheet\" href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/css/ie9.css"), "html", null, true);
        echo "\" /><![endif]-->
\t</head>
\t<body>

\t\t<!-- Header -->
\t\t\t<div id=\"header\">

\t\t\t\t<div class=\"top\">

\t\t\t\t\t<!-- Logo -->
\t\t\t\t\t\t<div id=\"logo\">
\t\t\t\t\t\t\t<span class=\"image avatar48\"><img src=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("images/avatar.jpg"), "html", null, true);
        echo "\" alt=\"\" /></span>
\t\t\t\t\t\t\t<h1 id=\"title\">QUIZ</h1>
\t\t\t\t\t\t\t<p> ";
        // line 23
        $this->displayBlock('prfil', $context, $blocks);
        echo " </p>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t
\t\t\t\t\t\t";
        // line 26
        $this->displayBlock('menu', $context, $blocks);
        // line 50
        echo "\t\t\t\t</div>

\t\t\t</div>

\t\t<!-- Main -->
\t\t\t<div id=\"main\">

\t\t\t\t<!-- Intro -->
\t\t\t\t\t<section id=\"top\">
\t\t\t\t\t\t

\t\t\t\t\t\t<div class=\"container\">

\t\t\t\t\t\t\t";
        // line 63
        if ($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "has", array(0 => "email"), "method")) {
            // line 64
            echo "\t\t\t\t\t\t\t\t<div class=\"container\" >
\t\t\t\t\t\t\t\t\t<br/><br/>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t";
        } else {
            // line 68
            echo "\t\t\t\t\t\t\t\t<a href=\"";
            echo $this->env->getExtension('routing')->getPath("home");
            echo "\"><button class=\"button button--simple button--border-thin button--text-thick button--text-upper button--size-s\" data-text=\"Home\"><span>Home</span></button></a>

\t\t\t\t\t\t\t\t<a href=\"";
            // line 70
            echo $this->env->getExtension('routing')->getPath("connexion");
            echo "\"><button class=\"button button--simple button--border-thin button--text-thick button--text-upper button--size-s\" data-text=\"Connexion\"><span>Connexion</span></button></a>

\t\t\t\t\t\t\t\t<a href=\"";
            // line 72
            echo $this->env->getExtension('routing')->getPath("inscription");
            echo "\"><button class=\"button button--simple button--border-thin button--text-thick button--text-upper button--size-s\" data-text=\"Inscription\"><span>Inscription</span></button></a>

\t\t\t\t\t\t\t\t<a href=\"";
            // line 74
            echo $this->env->getExtension('routing')->getPath("noteall");
            echo "\"><button class=\"button button--simple button--border-thin button--text-thick button--text-upper button--size-s\" data-text=\"Notes\"><span>Notes</span></button></a>
\t\t\t\t\t\t\t";
        }
        // line 76
        echo "
\t\t\t\t\t\t</div>\t
\t\t\t\t\t\t
\t\t\t\t\t</section>



\t\t\t\t\t";
        // line 83
        $this->displayBlock('content', $context, $blocks);
        // line 84
        echo "
\t\t\t\t

\t\t\t

\t\t\t</div>

\t\t<!-- Footer -->
\t\t\t<div id=\"footer\">

\t\t\t\t<!-- Copyright -->
\t\t\t\t\t<ul class=\"copyright\">
\t\t\t\t\t\t<li>&copy; Copyleft. All rights reserved.</li>
\t\t\t\t\t</ul>

\t\t\t</div>

\t\t<!-- Scripts -->
\t\t\t<script src=\"";
        // line 102
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/js/jquery.min.js"), "html", null, true);
        echo "\"></script>
\t\t\t<script src=\"";
        // line 103
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/js/jquery.scrolly.min.js"), "html", null, true);
        echo "\"></script>
\t\t\t<script src=\"";
        // line 104
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/js/jquery.scrollzer.min.js"), "html", null, true);
        echo "\"></script>
\t\t\t<script src=\"";
        // line 105
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/js/skel.min.js"), "html", null, true);
        echo "\"></script>
\t\t\t<script src=\"";
        // line 106
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/js/util.js"), "html", null, true);
        echo "\"></script>
\t\t\t<!--[if lte IE 8]><script src=\"assets/js/ie/respond.min.js\"></script><![endif]-->
\t\t\t<script src=\"";
        // line 108
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/js/main.js"), "html", null, true);
        echo "\"></script>

\t</body>
</html>

";
        
        $__internal_6b5a8102dacab3fa5e1383f0338bda63a2b56edc70895fb77ed50c7700888a1f->leave($__internal_6b5a8102dacab3fa5e1383f0338bda63a2b56edc70895fb77ed50c7700888a1f_prof);

    }

    // line 23
    public function block_prfil($context, array $blocks = array())
    {
        $__internal_9db841d9afa1436b85acb57edf9e35eb640dd03272c39249b1e03e19f46dbb03 = $this->env->getExtension("native_profiler");
        $__internal_9db841d9afa1436b85acb57edf9e35eb640dd03272c39249b1e03e19f46dbb03->enter($__internal_9db841d9afa1436b85acb57edf9e35eb640dd03272c39249b1e03e19f46dbb03_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "prfil"));

        echo " ";
        
        $__internal_9db841d9afa1436b85acb57edf9e35eb640dd03272c39249b1e03e19f46dbb03->leave($__internal_9db841d9afa1436b85acb57edf9e35eb640dd03272c39249b1e03e19f46dbb03_prof);

    }

    // line 26
    public function block_menu($context, array $blocks = array())
    {
        $__internal_da82a251fa0a7b8bdf9393f1dd6e19035dc0560974983099e52cb6f3bd207dbc = $this->env->getExtension("native_profiler");
        $__internal_da82a251fa0a7b8bdf9393f1dd6e19035dc0560974983099e52cb6f3bd207dbc->enter($__internal_da82a251fa0a7b8bdf9393f1dd6e19035dc0560974983099e52cb6f3bd207dbc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        echo " 

\t\t\t\t\t\t";
        // line 28
        if ($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "has", array(0 => "email"), "method")) {
            // line 29
            echo "\t\t\t\t\t\t\t";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "get", array(0 => "email"), "method"), "html", null, true);
            echo "
\t\t\t\t\t\t";
        } else {
            // line 31
            echo "
\t\t\t\t\t\t";
        }
        // line 33
        echo "\t\t\t\t\t\t\t
\t\t\t\t\t\t\t";
        // line 34
        if ($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "has", array(0 => "email"), "method")) {
            // line 35
            echo "\t\t\t\t\t\t\t
\t\t\t\t\t\t\t    <nav id=\"nav\">
\t\t\t\t\t\t\t\t\t<ul>
\t\t\t\t\t\t\t\t\t\t<li><a href=\"";
            // line 38
            echo $this->env->getExtension('routing')->getPath("home");
            echo "\" class=\"skel-layers-ignoreHref\"><span class=\"icon fa-home\">Faire un Quiz</span></a></li>
\t\t\t\t\t\t\t\t\t\t<li><a href=\"";
            // line 39
            echo $this->env->getExtension('routing')->getPath("creatquiz");
            echo "\" class=\"skel-layers-ignoreHref\"><span class=\"icon fa-home\">Creer un Quiz</span></a></li>
\t\t\t\t\t\t\t\t\t\t<li><a href=\"";
            // line 40
            echo $this->env->getExtension('routing')->getPath("profil");
            echo "\" class=\"skel-layers-ignoreHref\"><span class=\"icon fa-th\">Mon Profil</span></a></li>
\t\t\t\t\t\t\t\t\t\t<li><a href=\"";
            // line 41
            echo $this->env->getExtension('routing')->getPath("notes");
            echo "\" class=\"skel-layers-ignoreHref\"><span class=\"icon fa-user\">Mes Notes</span></a></li>
\t\t\t\t\t\t\t\t\t\t<li><a href=\"";
            // line 42
            echo $this->env->getExtension('routing')->getPath("logout");
            echo "\" class=\"skel-layers-ignoreHref\"><span class=\"icon fa-user\">Déconnexion</span></a></li>
\t\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t\t</nav>
\t\t\t\t\t\t\t";
        } else {
            // line 46
            echo "
\t\t\t\t\t\t\t";
        }
        // line 48
        echo "
\t\t\t\t\t";
        
        $__internal_da82a251fa0a7b8bdf9393f1dd6e19035dc0560974983099e52cb6f3bd207dbc->leave($__internal_da82a251fa0a7b8bdf9393f1dd6e19035dc0560974983099e52cb6f3bd207dbc_prof);

    }

    // line 83
    public function block_content($context, array $blocks = array())
    {
        $__internal_ae9879ee96b8b7600644d36bc4b2bd68e6cfecdf642c97604acd5a845f913622 = $this->env->getExtension("native_profiler");
        $__internal_ae9879ee96b8b7600644d36bc4b2bd68e6cfecdf642c97604acd5a845f913622->enter($__internal_ae9879ee96b8b7600644d36bc4b2bd68e6cfecdf642c97604acd5a845f913622_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        echo " ";
        
        $__internal_ae9879ee96b8b7600644d36bc4b2bd68e6cfecdf642c97604acd5a845f913622->leave($__internal_ae9879ee96b8b7600644d36bc4b2bd68e6cfecdf642c97604acd5a845f913622_prof);

    }

    public function getTemplateName()
    {
        return "HomeBundle::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  256 => 83,  248 => 48,  244 => 46,  237 => 42,  233 => 41,  229 => 40,  225 => 39,  221 => 38,  216 => 35,  214 => 34,  211 => 33,  207 => 31,  201 => 29,  199 => 28,  190 => 26,  178 => 23,  165 => 108,  160 => 106,  156 => 105,  152 => 104,  148 => 103,  144 => 102,  124 => 84,  122 => 83,  113 => 76,  108 => 74,  103 => 72,  98 => 70,  92 => 68,  86 => 64,  84 => 63,  69 => 50,  67 => 26,  61 => 23,  56 => 21,  42 => 10,  38 => 9,  34 => 8,  25 => 1,);
    }
}
/* <!DOCTYPE HTML>*/
/* <html>*/
/* 	<head>*/
/* 		<title>QUIZ HOME</title>*/
/* 		<meta charset="utf-8" />*/
/* 		<meta name="viewport" content="width=device-width, initial-scale=1" />*/
/* 		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->*/
/* 		<link rel="stylesheet" href="{{ asset('assets/css/main.css') }}" />*/
/* 		<!--[if lte IE 8]><link rel="stylesheet" href="{{ asset('assets/css/ie8.css') }}" /><![endif]-->*/
/* 		<!--[if lte IE 9]><link rel="stylesheet" href="{{ asset('assets/css/ie9.css') }}" /><![endif]-->*/
/* 	</head>*/
/* 	<body>*/
/* */
/* 		<!-- Header -->*/
/* 			<div id="header">*/
/* */
/* 				<div class="top">*/
/* */
/* 					<!-- Logo -->*/
/* 						<div id="logo">*/
/* 							<span class="image avatar48"><img src="{{ asset('images/avatar.jpg') }}" alt="" /></span>*/
/* 							<h1 id="title">QUIZ</h1>*/
/* 							<p> {% block prfil %} {% endblock %} </p>*/
/* 						</div>*/
/* 							*/
/* 						{% block menu %} */
/* */
/* 						{% if app.session.has('email') %}*/
/* 							{{app.session.get('email')}}*/
/* 						{% else%}*/
/* */
/* 						{% endif%}*/
/* 							*/
/* 							{% if app.session.has('email') %}*/
/* 							*/
/* 							    <nav id="nav">*/
/* 									<ul>*/
/* 										<li><a href="{{ path('home') }}" class="skel-layers-ignoreHref"><span class="icon fa-home">Faire un Quiz</span></a></li>*/
/* 										<li><a href="{{ path('creatquiz') }}" class="skel-layers-ignoreHref"><span class="icon fa-home">Creer un Quiz</span></a></li>*/
/* 										<li><a href="{{ path('profil') }}" class="skel-layers-ignoreHref"><span class="icon fa-th">Mon Profil</span></a></li>*/
/* 										<li><a href="{{ path('notes') }}" class="skel-layers-ignoreHref"><span class="icon fa-user">Mes Notes</span></a></li>*/
/* 										<li><a href="{{ path('logout') }}" class="skel-layers-ignoreHref"><span class="icon fa-user">Déconnexion</span></a></li>*/
/* 									</ul>*/
/* 								</nav>*/
/* 							{% else%}*/
/* */
/* 							{% endif %}*/
/* */
/* 					{% endblock %}*/
/* 				</div>*/
/* */
/* 			</div>*/
/* */
/* 		<!-- Main -->*/
/* 			<div id="main">*/
/* */
/* 				<!-- Intro -->*/
/* 					<section id="top">*/
/* 						*/
/* */
/* 						<div class="container">*/
/* */
/* 							{% if app.session.has('email') %}*/
/* 								<div class="container" >*/
/* 									<br/><br/>*/
/* 								</div>*/
/* 							{% else%}*/
/* 								<a href="{{ path('home') }}"><button class="button button--simple button--border-thin button--text-thick button--text-upper button--size-s" data-text="Home"><span>Home</span></button></a>*/
/* */
/* 								<a href="{{ path('connexion') }}"><button class="button button--simple button--border-thin button--text-thick button--text-upper button--size-s" data-text="Connexion"><span>Connexion</span></button></a>*/
/* */
/* 								<a href="{{ path('inscription') }}"><button class="button button--simple button--border-thin button--text-thick button--text-upper button--size-s" data-text="Inscription"><span>Inscription</span></button></a>*/
/* */
/* 								<a href="{{ path('noteall') }}"><button class="button button--simple button--border-thin button--text-thick button--text-upper button--size-s" data-text="Notes"><span>Notes</span></button></a>*/
/* 							{% endif %}*/
/* */
/* 						</div>	*/
/* 						*/
/* 					</section>*/
/* */
/* */
/* */
/* 					{% block content %} {% endblock %}*/
/* */
/* 				*/
/* */
/* 			*/
/* */
/* 			</div>*/
/* */
/* 		<!-- Footer -->*/
/* 			<div id="footer">*/
/* */
/* 				<!-- Copyright -->*/
/* 					<ul class="copyright">*/
/* 						<li>&copy; Copyleft. All rights reserved.</li>*/
/* 					</ul>*/
/* */
/* 			</div>*/
/* */
/* 		<!-- Scripts -->*/
/* 			<script src="{{ asset('assets/js/jquery.min.js') }}"></script>*/
/* 			<script src="{{ asset('assets/js/jquery.scrolly.min.js') }}"></script>*/
/* 			<script src="{{ asset('assets/js/jquery.scrollzer.min.js') }}"></script>*/
/* 			<script src="{{ asset('assets/js/skel.min.js') }}"></script>*/
/* 			<script src="{{ asset('assets/js/util.js') }}"></script>*/
/* 			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->*/
/* 			<script src="{{ asset('assets/js/main.js') }}"></script>*/
/* */
/* 	</body>*/
/* </html>*/
/* */
/* */
