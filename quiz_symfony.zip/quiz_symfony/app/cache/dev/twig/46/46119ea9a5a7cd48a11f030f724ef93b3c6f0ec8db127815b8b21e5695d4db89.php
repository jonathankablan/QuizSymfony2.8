<?php

/* HomeBundle:Default:quiz.html.twig */
class __TwigTemplate_3b7d9afbfcd9fc634345a1951924c91a7cb14dfdba14bf99679c7d917ca7d1f8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("HomeBundle::base.html.twig", "HomeBundle:Default:quiz.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "HomeBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_53909ce9d603f891a27541b58c8037656575c13769f72228f122f10188e51b89 = $this->env->getExtension("native_profiler");
        $__internal_53909ce9d603f891a27541b58c8037656575c13769f72228f122f10188e51b89->enter($__internal_53909ce9d603f891a27541b58c8037656575c13769f72228f122f10188e51b89_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "HomeBundle:Default:quiz.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_53909ce9d603f891a27541b58c8037656575c13769f72228f122f10188e51b89->leave($__internal_53909ce9d603f891a27541b58c8037656575c13769f72228f122f10188e51b89_prof);

    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        $__internal_b044ff86d99905d26b0d82a850852f35a28919107d0820ae54be3e0fb900d415 = $this->env->getExtension("native_profiler");
        $__internal_b044ff86d99905d26b0d82a850852f35a28919107d0820ae54be3e0fb900d415->enter($__internal_b044ff86d99905d26b0d82a850852f35a28919107d0820ae54be3e0fb900d415_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "
\t<section>
\t\t<div class=\"container\">

\t\t\t<h1>Qestion du Quiz</h1>

\t\t\t";
        // line 10
        if (array_key_exists("note", $context)) {
            // line 11
            echo "\t\t\t\t<div class=\"alert alert-success\">
\t\t\t\t\tNotes : ";
            // line 12
            echo twig_escape_filter($this->env, (isset($context["note"]) ? $context["note"] : $this->getContext($context, "note")), "html", null, true);
            echo " % <br/>
\t\t\t\t<div>
\t\t\t";
        }
        // line 15
        echo "
\t\t\t";
        // line 16
        if ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashBag", array()), "has", array(0 => "note_send"), "method")) {
            // line 17
            echo "\t\t\t\t<div class=\"alert alert-success\">
\t\t\t\t";
            // line 18
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashBag", array()), "get", array(0 => "note_send"), "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["msg"]) {
                // line 19
                echo "\t\t\t\t\t";
                echo twig_escape_filter($this->env, $context["msg"], "html", null, true);
                echo "
\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['msg'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 21
            echo "\t\t\t\t<div>
\t\t\t";
        }
        // line 23
        echo "\t\t\t<hr/>
\t\t\t<form method=\"POST\" action=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("quiz", array("item" => (isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")))), "html", null, true);
        echo "\">
\t\t\t\t";
        // line 25
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["quiz"]) ? $context["quiz"] : $this->getContext($context, "quiz")));
        foreach ($context['_seq'] as $context["_key"] => $context["quiz_User"]) {
            // line 26
            echo "\t\t\t\t\t<p>* - ";
            echo twig_escape_filter($this->env, $this->getAttribute($context["quiz_User"], "question", array()), "html", null, true);
            echo " 

\t\t\t\t     <span class=\"btn\">
\t\t\t\t      Vrai : <input type=\"radio\" name=\"rep";
            // line 29
            echo twig_escape_filter($this->env, $this->getAttribute($context["quiz_User"], "id", array()), "html", null, true);
            echo "\" value=\"1\"/>  / 
\t\t\t\t      Faux : <input type=\"radio\" name=\"rep";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute($context["quiz_User"], "id", array()), "html", null, true);
            echo "\" value=\"0\"/> 
\t\t\t\t      </span>
\t\t\t\t    </p> <hr />
\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['quiz_User'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 34
        echo "\t\t\t\t<input class=\"btn\" type=\"submit\" value=\"Terminer\" style=\"width:200px;font-size:20px;\">
\t\t\t</form>
\t\t</div>

\t</section>

";
        
        $__internal_b044ff86d99905d26b0d82a850852f35a28919107d0820ae54be3e0fb900d415->leave($__internal_b044ff86d99905d26b0d82a850852f35a28919107d0820ae54be3e0fb900d415_prof);

    }

    public function getTemplateName()
    {
        return "HomeBundle:Default:quiz.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  116 => 34,  106 => 30,  102 => 29,  95 => 26,  91 => 25,  87 => 24,  84 => 23,  80 => 21,  71 => 19,  67 => 18,  64 => 17,  62 => 16,  59 => 15,  53 => 12,  50 => 11,  48 => 10,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'HomeBundle::base.html.twig' %}*/
/* */
/* {% block content %}*/
/* */
/* 	<section>*/
/* 		<div class="container">*/
/* */
/* 			<h1>Qestion du Quiz</h1>*/
/* */
/* 			{% if note is defined %}*/
/* 				<div class="alert alert-success">*/
/* 					Notes : {{ note }} % <br/>*/
/* 				<div>*/
/* 			{% endif %}*/
/* */
/* 			{% if app.session.flashBag.has('note_send') %}*/
/* 				<div class="alert alert-success">*/
/* 				{% for msg in app.session.flashBag.get('note_send') %}*/
/* 					{{ msg }}*/
/* 				{% endfor %}*/
/* 				<div>*/
/* 			{% endif %}*/
/* 			<hr/>*/
/* 			<form method="POST" action="{{ path('quiz', {item: item}) }}">*/
/* 				{% for quiz_User in quiz %}*/
/* 					<p>* - {{ quiz_User.question }} */
/* */
/* 				     <span class="btn">*/
/* 				      Vrai : <input type="radio" name="rep{{ quiz_User.id }}" value="1"/>  / */
/* 				      Faux : <input type="radio" name="rep{{ quiz_User.id }}" value="0"/> */
/* 				      </span>*/
/* 				    </p> <hr />*/
/* 				{% endfor %}*/
/* 				<input class="btn" type="submit" value="Terminer" style="width:200px;font-size:20px;">*/
/* 			</form>*/
/* 		</div>*/
/* */
/* 	</section>*/
/* */
/* {% endblock %}*/
