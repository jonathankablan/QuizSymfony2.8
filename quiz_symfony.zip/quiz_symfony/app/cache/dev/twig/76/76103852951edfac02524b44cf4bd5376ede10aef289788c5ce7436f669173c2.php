<?php

/* HomeBundle:Default:index.html.twig */
class __TwigTemplate_e85622a9e0f533395aba842e61a841d4010cb50512ddbc1895b339c6eaa6bc63 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("HomeBundle::base.html.twig", "HomeBundle:Default:index.html.twig", 2);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "HomeBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_08d01d42872b386045386092b94e51d21d00012f24f852d0833d0007318d6062 = $this->env->getExtension("native_profiler");
        $__internal_08d01d42872b386045386092b94e51d21d00012f24f852d0833d0007318d6062->enter($__internal_08d01d42872b386045386092b94e51d21d00012f24f852d0833d0007318d6062_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "HomeBundle:Default:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_08d01d42872b386045386092b94e51d21d00012f24f852d0833d0007318d6062->leave($__internal_08d01d42872b386045386092b94e51d21d00012f24f852d0833d0007318d6062_prof);

    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        $__internal_298854c8e0bfb1c54816a468a19c31a14efe16572b8a259a1906cd6913bb0091 = $this->env->getExtension("native_profiler");
        $__internal_298854c8e0bfb1c54816a468a19c31a14efe16572b8a259a1906cd6913bb0091->enter($__internal_298854c8e0bfb1c54816a468a19c31a14efe16572b8a259a1906cd6913bb0091_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 6
        echo "<section id=\"portfolio\" class=\"two\">
\t\t\t\t\t\t<div class=\"container\">

\t\t\t\t\t\t\t<header>
\t\t\t\t\t\t\t\t<h2>Bienvenue au Quiz</h2>
\t\t\t\t\t\t\t</header>

\t\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t\t";
        // line 14
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["themes"]) ? $context["themes"] : $this->getContext($context, "themes")));
        foreach ($context['_seq'] as $context["_key"] => $context["theme"]) {
            // line 15
            echo "\t\t\t\t\t\t\t\t\t<div class=\"4u 12u\$(mobile)\">
\t\t\t\t\t\t\t\t\t\t<a href=\"";
            // line 16
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("quiz", array("item" => $this->getAttribute($context["theme"], "id", array()))), "html", null, true);
            echo "\" class=\"image fit\">
\t\t\t\t\t\t\t\t\t\t\t<article class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t<img src=\"";
            // line 18
            echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("images/pic06.jpg"), "html", null, true);
            echo "\" alt=\"\" />
\t\t\t\t\t\t\t\t\t\t\t\t<header>
\t\t\t\t\t\t\t\t\t\t\t\t\t<h3> ";
            // line 20
            echo twig_escape_filter($this->env, $this->getAttribute($context["theme"], "name", array()), "html", null, true);
            echo " </h3>
\t\t\t\t\t\t\t\t\t\t\t\t</header>
\t\t\t\t\t\t\t\t\t\t\t</article>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['theme'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 26
        echo "\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t</div>
\t\t\t\t\t</section>

";
        
        $__internal_298854c8e0bfb1c54816a468a19c31a14efe16572b8a259a1906cd6913bb0091->leave($__internal_298854c8e0bfb1c54816a468a19c31a14efe16572b8a259a1906cd6913bb0091_prof);

    }

    public function getTemplateName()
    {
        return "HomeBundle:Default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  79 => 26,  67 => 20,  62 => 18,  57 => 16,  54 => 15,  50 => 14,  40 => 6,  34 => 5,  11 => 2,);
    }
}
/* */
/* {% extends 'HomeBundle::base.html.twig' %}*/
/* */
/* */
/* {% block content %}*/
/* <section id="portfolio" class="two">*/
/* 						<div class="container">*/
/* */
/* 							<header>*/
/* 								<h2>Bienvenue au Quiz</h2>*/
/* 							</header>*/
/* */
/* 							<div class="row">*/
/* 								{% for theme in themes %}*/
/* 									<div class="4u 12u$(mobile)">*/
/* 										<a href="{{ path('quiz', {'item': theme.id }) }}" class="image fit">*/
/* 											<article class="item">*/
/* 												<img src="{{ asset('images/pic06.jpg') }}" alt="" />*/
/* 												<header>*/
/* 													<h3> {{ theme.name }} </h3>*/
/* 												</header>*/
/* 											</article>*/
/* 										</a>*/
/* 									</div>*/
/* 								{% endfor %}*/
/* 							</div>*/
/* */
/* 						</div>*/
/* 					</section>*/
/* */
/* {% endblock %}*/
