<?php

/* HomeBundle:Default:question.html.twig */
class __TwigTemplate_17922754173813a14d1e0121434ee44240b0ee68252546b411690d2b5f12ee54 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("HomeBundle::base.html.twig", "HomeBundle:Default:question.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "HomeBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6bc44f9a1ffc66fb30d94c057c9bae39ff0686c9278298532fb2ea3eaad8a29e = $this->env->getExtension("native_profiler");
        $__internal_6bc44f9a1ffc66fb30d94c057c9bae39ff0686c9278298532fb2ea3eaad8a29e->enter($__internal_6bc44f9a1ffc66fb30d94c057c9bae39ff0686c9278298532fb2ea3eaad8a29e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "HomeBundle:Default:question.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6bc44f9a1ffc66fb30d94c057c9bae39ff0686c9278298532fb2ea3eaad8a29e->leave($__internal_6bc44f9a1ffc66fb30d94c057c9bae39ff0686c9278298532fb2ea3eaad8a29e_prof);

    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        $__internal_a74a546b6332080cba37f10752426b9b0da4703ee459e387d9e0347e9162df75 = $this->env->getExtension("native_profiler");
        $__internal_a74a546b6332080cba37f10752426b9b0da4703ee459e387d9e0347e9162df75->enter($__internal_a74a546b6332080cba37f10752426b9b0da4703ee459e387d9e0347e9162df75_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "
\t<section>
\t\t<div class=\"container\">

\t\t";
        // line 8
        if ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashBag", array()), "has", array(0 => "success"), "method")) {
            // line 9
            echo "\t\t\t<div class=\"alert alert-success\">
\t\t\t";
            // line 10
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashBag", array()), "get", array(0 => "success"), "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["msg"]) {
                // line 11
                echo "\t\t\t\t";
                echo twig_escape_filter($this->env, $context["msg"], "html", null, true);
                echo "
\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['msg'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 13
            echo "\t\t\t<div>
\t\t";
        }
        // line 15
        echo "
\t\t";
        // line 16
        if ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashBag", array()), "has", array(0 => "error"), "method")) {
            // line 17
            echo "\t\t\t<div class=\"alert alert-danger\">
\t\t\t";
            // line 18
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashBag", array()), "get", array(0 => "error"), "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["msg"]) {
                // line 19
                echo "\t\t\t\t";
                echo twig_escape_filter($this->env, $context["msg"], "html", null, true);
                echo "
\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['msg'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 21
            echo "\t\t\t<div>
\t\t";
        }
        // line 23
        echo "
\t\t\t
\t\t\t\t <div class=\"box2\">
\t\t\t\t    <div class=\"content\">
\t\t\t\t    

\t\t\t\t      <h1>Qestion du Quiz</h1>
\t\t\t\t      <form method=\"POST\" action=\"";
        // line 30
        echo $this->env->getExtension('routing')->getPath("questionquiz");
        echo "\">
\t\t\t\t      \t  <select name=\"idtheme\" required>
\t\t\t\t      \t  \t";
        // line 32
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["themes"]) ? $context["themes"] : $this->getContext($context, "themes")));
        foreach ($context['_seq'] as $context["_key"] => $context["theme"]) {
            // line 33
            echo "\t\t\t\t      \t  \t\t<option value='";
            echo twig_escape_filter($this->env, $this->getAttribute($context["theme"], "id", array()), "html", null, true);
            echo "'>";
            echo twig_escape_filter($this->env, $this->getAttribute($context["theme"], "name", array()), "html", null, true);
            echo "</option>
\t\t\t\t      \t  \t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['theme'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 35
        echo "\t\t\t\t      \t  </select> <br/>
\t\t\t\t\t      <input class=\"field\" type=\"text\" name=\"question\" placeholder=\"Your Question\" required><br>
\t\t\t\t\t      Vrai : <input type=\"radio\" name=\"reponse\" value=\"1\" required/> <br />
\t\t\t\t\t      Faux : <input type=\"radio\" name=\"reponse\" value=\"0\" required/> <br />
\t\t\t\t\t      <input class=\"btn\" type=\"submit\" value=\"Created\" style=\"width:200px;font-size:20px;\">
\t\t\t\t      </form>
\t\t\t\t    </div>
\t\t\t\t  </div>
\t\t\t

\t\t</div>
\t</section>

";
        
        $__internal_a74a546b6332080cba37f10752426b9b0da4703ee459e387d9e0347e9162df75->leave($__internal_a74a546b6332080cba37f10752426b9b0da4703ee459e387d9e0347e9162df75_prof);

    }

    public function getTemplateName()
    {
        return "HomeBundle:Default:question.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  122 => 35,  111 => 33,  107 => 32,  102 => 30,  93 => 23,  89 => 21,  80 => 19,  76 => 18,  73 => 17,  71 => 16,  68 => 15,  64 => 13,  55 => 11,  51 => 10,  48 => 9,  46 => 8,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'HomeBundle::base.html.twig' %}*/
/* */
/* {% block content %}*/
/* */
/* 	<section>*/
/* 		<div class="container">*/
/* */
/* 		{% if app.session.flashBag.has('success') %}*/
/* 			<div class="alert alert-success">*/
/* 			{% for msg in app.session.flashBag.get('success') %}*/
/* 				{{ msg }}*/
/* 			{% endfor %}*/
/* 			<div>*/
/* 		{% endif %}*/
/* */
/* 		{% if app.session.flashBag.has('error') %}*/
/* 			<div class="alert alert-danger">*/
/* 			{% for msg in app.session.flashBag.get('error') %}*/
/* 				{{ msg }}*/
/* 			{% endfor %}*/
/* 			<div>*/
/* 		{% endif %}*/
/* */
/* 			*/
/* 				 <div class="box2">*/
/* 				    <div class="content">*/
/* 				    */
/* */
/* 				      <h1>Qestion du Quiz</h1>*/
/* 				      <form method="POST" action="{{ path('questionquiz') }}">*/
/* 				      	  <select name="idtheme" required>*/
/* 				      	  	{% for theme in themes %}*/
/* 				      	  		<option value='{{ theme.id}}'>{{ theme.name }}</option>*/
/* 				      	  	{% endfor %}*/
/* 				      	  </select> <br/>*/
/* 					      <input class="field" type="text" name="question" placeholder="Your Question" required><br>*/
/* 					      Vrai : <input type="radio" name="reponse" value="1" required/> <br />*/
/* 					      Faux : <input type="radio" name="reponse" value="0" required/> <br />*/
/* 					      <input class="btn" type="submit" value="Created" style="width:200px;font-size:20px;">*/
/* 				      </form>*/
/* 				    </div>*/
/* 				  </div>*/
/* 			*/
/* */
/* 		</div>*/
/* 	</section>*/
/* */
/* {% endblock %}*/
