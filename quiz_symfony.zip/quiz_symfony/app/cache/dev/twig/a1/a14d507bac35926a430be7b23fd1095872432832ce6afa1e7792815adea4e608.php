<?php

/* HomeBundle:Default:connexion.html.twig */
class __TwigTemplate_627d9f5046116f70ab1bb015c1d30e05ae6f0a4ded963e01af97e5ba54519317 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("HomeBundle::base.html.twig", "HomeBundle:Default:connexion.html.twig", 2);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "HomeBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_685a85e67db19c18a673bb44eb71e7d1eaaf90edb0ad09cabbdf0162e0880d66 = $this->env->getExtension("native_profiler");
        $__internal_685a85e67db19c18a673bb44eb71e7d1eaaf90edb0ad09cabbdf0162e0880d66->enter($__internal_685a85e67db19c18a673bb44eb71e7d1eaaf90edb0ad09cabbdf0162e0880d66_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "HomeBundle:Default:connexion.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_685a85e67db19c18a673bb44eb71e7d1eaaf90edb0ad09cabbdf0162e0880d66->leave($__internal_685a85e67db19c18a673bb44eb71e7d1eaaf90edb0ad09cabbdf0162e0880d66_prof);

    }

    // line 4
    public function block_content($context, array $blocks = array())
    {
        $__internal_9f7b147657b6991b19e1a75efcd0a75e7ef3c9c85e998c24456bd57b4dc8bf24 = $this->env->getExtension("native_profiler");
        $__internal_9f7b147657b6991b19e1a75efcd0a75e7ef3c9c85e998c24456bd57b4dc8bf24->enter($__internal_9f7b147657b6991b19e1a75efcd0a75e7ef3c9c85e998c24456bd57b4dc8bf24_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 5
        echo "
\t<section>
\t\t<div class=\"container\">

\t\t<form method=\"POST\" action=\"";
        // line 9
        echo $this->env->getExtension('routing')->getPath("connexion");
        echo "\">
\t\t\t\t <div class=\"box\">
\t\t\t\t    <div class=\"content\">
\t\t\t\t      <h1>Authentication</h1>
\t\t\t\t      <input class=\"field\" type=\"text\" name=\"email\" placeholder=\"Your Email\"><br>
\t\t\t\t      <input class=\"field\" type=\"password\" name=\"password\" placeholder=\"Your Password\"><br>
\t\t\t\t      <input class=\"btn\" type=\"submit\" value=\"Connexion\">  
\t\t\t\t    </div>
\t\t\t\t  </div>
\t\t\t</form>

\t\t</div>
\t</section>

";
        
        $__internal_9f7b147657b6991b19e1a75efcd0a75e7ef3c9c85e998c24456bd57b4dc8bf24->leave($__internal_9f7b147657b6991b19e1a75efcd0a75e7ef3c9c85e998c24456bd57b4dc8bf24_prof);

    }

    public function getTemplateName()
    {
        return "HomeBundle:Default:connexion.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  46 => 9,  40 => 5,  34 => 4,  11 => 2,);
    }
}
/* */
/* {% extends 'HomeBundle::base.html.twig' %}*/
/* */
/* {% block content %}*/
/* */
/* 	<section>*/
/* 		<div class="container">*/
/* */
/* 		<form method="POST" action="{{ path('connexion') }}">*/
/* 				 <div class="box">*/
/* 				    <div class="content">*/
/* 				      <h1>Authentication</h1>*/
/* 				      <input class="field" type="text" name="email" placeholder="Your Email"><br>*/
/* 				      <input class="field" type="password" name="password" placeholder="Your Password"><br>*/
/* 				      <input class="btn" type="submit" value="Connexion">  */
/* 				    </div>*/
/* 				  </div>*/
/* 			</form>*/
/* */
/* 		</div>*/
/* 	</section>*/
/* */
/* {% endblock %}*/
