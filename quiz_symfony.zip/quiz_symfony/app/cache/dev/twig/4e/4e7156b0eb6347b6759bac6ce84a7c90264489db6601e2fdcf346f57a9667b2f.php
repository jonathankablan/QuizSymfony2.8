<?php

/* HomeBundle:Default:creat.html.twig */
class __TwigTemplate_05f11aae1ff098037b5990f9a9b983eb60c911d6793536fca6ebb42e3948995a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("HomeBundle::base.html.twig", "HomeBundle:Default:creat.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "HomeBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8a4f22fb062d69c7c6a4923784ea080ce709c3bb89565861d3d81832d8b819b8 = $this->env->getExtension("native_profiler");
        $__internal_8a4f22fb062d69c7c6a4923784ea080ce709c3bb89565861d3d81832d8b819b8->enter($__internal_8a4f22fb062d69c7c6a4923784ea080ce709c3bb89565861d3d81832d8b819b8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "HomeBundle:Default:creat.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8a4f22fb062d69c7c6a4923784ea080ce709c3bb89565861d3d81832d8b819b8->leave($__internal_8a4f22fb062d69c7c6a4923784ea080ce709c3bb89565861d3d81832d8b819b8_prof);

    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        $__internal_b8d74125aa4affb1eb78b3fb009a36d32fe2401a65a563bfa310ebdca8cb81c3 = $this->env->getExtension("native_profiler");
        $__internal_b8d74125aa4affb1eb78b3fb009a36d32fe2401a65a563bfa310ebdca8cb81c3->enter($__internal_b8d74125aa4affb1eb78b3fb009a36d32fe2401a65a563bfa310ebdca8cb81c3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "
\t<section>
\t\t<div class=\"container\">

\t\t";
        // line 8
        if ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashBag", array()), "has", array(0 => "success"), "method")) {
            // line 9
            echo "\t\t\t<div class=\"alert alert-success\">
\t\t\t";
            // line 10
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashBag", array()), "get", array(0 => "success"), "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["msg"]) {
                // line 11
                echo "\t\t\t\t";
                echo twig_escape_filter($this->env, $context["msg"], "html", null, true);
                echo "
\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['msg'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 13
            echo "\t\t\t<div>
\t\t";
        }
        // line 15
        echo "
\t\t";
        // line 16
        if ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashBag", array()), "has", array(0 => "error"), "method")) {
            // line 17
            echo "\t\t\t<div class=\"alert alert-danger\">
\t\t\t";
            // line 18
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashBag", array()), "get", array(0 => "error"), "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["msg"]) {
                // line 19
                echo "\t\t\t\t";
                echo twig_escape_filter($this->env, $context["msg"], "html", null, true);
                echo "
\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['msg'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 21
            echo "\t\t\t<div>
\t\t";
        }
        // line 23
        echo "
\t\t\t
\t\t\t\t <div class=\"box\">
\t\t\t\t    <div class=\"content\">
\t\t\t\t      <h1>Création du Quiz</h1>
\t\t\t\t      <form method=\"POST\" action=\"";
        // line 28
        echo $this->env->getExtension('routing')->getPath("creatquiz");
        echo "\">
\t\t\t\t\t      <input class=\"field\" type=\"text\" name=\"name\" placeholder=\"Your Theme\" required><br>
\t\t\t\t\t      <input class=\"btn\" type=\"submit\" value=\"Created\">
\t\t\t\t      </form>
\t\t\t\t      <hr>  
\t\t\t\t      <a href=\"";
        // line 33
        echo $this->env->getExtension('routing')->getPath("questionquiz");
        echo "\"><input class=\"btn\" type=\"submit\" value=\"Created Questions\"> </a>
\t\t\t\t    </div>
\t\t\t\t  </div>
\t\t\t

\t\t</div>
\t</section>

";
        
        $__internal_b8d74125aa4affb1eb78b3fb009a36d32fe2401a65a563bfa310ebdca8cb81c3->leave($__internal_b8d74125aa4affb1eb78b3fb009a36d32fe2401a65a563bfa310ebdca8cb81c3_prof);

    }

    public function getTemplateName()
    {
        return "HomeBundle:Default:creat.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  108 => 33,  100 => 28,  93 => 23,  89 => 21,  80 => 19,  76 => 18,  73 => 17,  71 => 16,  68 => 15,  64 => 13,  55 => 11,  51 => 10,  48 => 9,  46 => 8,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'HomeBundle::base.html.twig' %}*/
/* */
/* {% block content %}*/
/* */
/* 	<section>*/
/* 		<div class="container">*/
/* */
/* 		{% if app.session.flashBag.has('success') %}*/
/* 			<div class="alert alert-success">*/
/* 			{% for msg in app.session.flashBag.get('success') %}*/
/* 				{{ msg }}*/
/* 			{% endfor %}*/
/* 			<div>*/
/* 		{% endif %}*/
/* */
/* 		{% if app.session.flashBag.has('error') %}*/
/* 			<div class="alert alert-danger">*/
/* 			{% for msg in app.session.flashBag.get('error') %}*/
/* 				{{ msg }}*/
/* 			{% endfor %}*/
/* 			<div>*/
/* 		{% endif %}*/
/* */
/* 			*/
/* 				 <div class="box">*/
/* 				    <div class="content">*/
/* 				      <h1>Création du Quiz</h1>*/
/* 				      <form method="POST" action="{{ path('creatquiz') }}">*/
/* 					      <input class="field" type="text" name="name" placeholder="Your Theme" required><br>*/
/* 					      <input class="btn" type="submit" value="Created">*/
/* 				      </form>*/
/* 				      <hr>  */
/* 				      <a href="{{ path('questionquiz') }}"><input class="btn" type="submit" value="Created Questions"> </a>*/
/* 				    </div>*/
/* 				  </div>*/
/* 			*/
/* */
/* 		</div>*/
/* 	</section>*/
/* */
/* {% endblock %}*/
