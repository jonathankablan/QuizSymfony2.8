<?php

/* HomeBundle:Default:notes.html.twig */
class __TwigTemplate_b58ab6be6b797dcae582a30cf9890d365e972c6ec4ae7447b12dc18f9b1cd3e0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("HomeBundle::base.html.twig", "HomeBundle:Default:notes.html.twig", 2);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "HomeBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_31bdfdc851e903b0a6f652ebf2eec142f2ba700880d38391903b3dac96a27001 = $this->env->getExtension("native_profiler");
        $__internal_31bdfdc851e903b0a6f652ebf2eec142f2ba700880d38391903b3dac96a27001->enter($__internal_31bdfdc851e903b0a6f652ebf2eec142f2ba700880d38391903b3dac96a27001_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "HomeBundle:Default:notes.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_31bdfdc851e903b0a6f652ebf2eec142f2ba700880d38391903b3dac96a27001->leave($__internal_31bdfdc851e903b0a6f652ebf2eec142f2ba700880d38391903b3dac96a27001_prof);

    }

    // line 4
    public function block_content($context, array $blocks = array())
    {
        $__internal_0e2578e6747dd0f01fd1233bbe2922be5bd68f5bdd5d7614e3660f038318240f = $this->env->getExtension("native_profiler");
        $__internal_0e2578e6747dd0f01fd1233bbe2922be5bd68f5bdd5d7614e3660f038318240f->enter($__internal_0e2578e6747dd0f01fd1233bbe2922be5bd68f5bdd5d7614e3660f038318240f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 5
        echo "
\t<section>
\t\t<div class=\"container\">

\t\t\t<header>
\t\t\t\t<h2>Mes Notes</h2>
\t\t\t</header>

\t\t\t<div class=\"row\">
\t\t\t\t";
        // line 14
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["notes"]) ? $context["notes"] : $this->getContext($context, "notes")));
        foreach ($context['_seq'] as $context["_key"] => $context["note"]) {
            // line 15
            echo "\t\t\t\t\t<div class=\"2u 4u\$(mobile)\">
\t\t\t\t\t\t<article class=\"item\">
\t\t\t\t\t\t\t<header>
\t\t\t\t\t\t\t\t<h3> Ma Note </h3> <br />
\t\t\t\t\t\t\t\t<h3> ";
            // line 19
            echo twig_escape_filter($this->env, $this->getAttribute($context["note"], "note", array()), "html", null, true);
            echo " % </h3>
\t\t\t\t\t\t\t</header>
\t\t\t\t\t\t</article>
\t\t\t\t\t</div>
\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['note'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 24
        echo "\t\t\t</div>

\t\t</div>
\t</section>

";
        
        $__internal_0e2578e6747dd0f01fd1233bbe2922be5bd68f5bdd5d7614e3660f038318240f->leave($__internal_0e2578e6747dd0f01fd1233bbe2922be5bd68f5bdd5d7614e3660f038318240f_prof);

    }

    public function getTemplateName()
    {
        return "HomeBundle:Default:notes.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 24,  61 => 19,  55 => 15,  51 => 14,  40 => 5,  34 => 4,  11 => 2,);
    }
}
/* */
/* {% extends 'HomeBundle::base.html.twig' %}*/
/* */
/* {% block content %}*/
/* */
/* 	<section>*/
/* 		<div class="container">*/
/* */
/* 			<header>*/
/* 				<h2>Mes Notes</h2>*/
/* 			</header>*/
/* */
/* 			<div class="row">*/
/* 				{% for note in notes %}*/
/* 					<div class="2u 4u$(mobile)">*/
/* 						<article class="item">*/
/* 							<header>*/
/* 								<h3> Ma Note </h3> <br />*/
/* 								<h3> {{ note.note }} % </h3>*/
/* 							</header>*/
/* 						</article>*/
/* 					</div>*/
/* 				{% endfor %}*/
/* 			</div>*/
/* */
/* 		</div>*/
/* 	</section>*/
/* */
/* {% endblock %}*/
