<?php

/* HomeBundle:Default:inscription.html.twig */
class __TwigTemplate_7f2eb8785d881323587170db94405e4cbc7360f6759b11551ff2e101db65eb7c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("HomeBundle::base.html.twig", "HomeBundle:Default:inscription.html.twig", 3);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "HomeBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_77ceb3c6e0efdbb62434627abfdc0feae0a996e4c774f4a1deb52c1783045360 = $this->env->getExtension("native_profiler");
        $__internal_77ceb3c6e0efdbb62434627abfdc0feae0a996e4c774f4a1deb52c1783045360->enter($__internal_77ceb3c6e0efdbb62434627abfdc0feae0a996e4c774f4a1deb52c1783045360_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "HomeBundle:Default:inscription.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_77ceb3c6e0efdbb62434627abfdc0feae0a996e4c774f4a1deb52c1783045360->leave($__internal_77ceb3c6e0efdbb62434627abfdc0feae0a996e4c774f4a1deb52c1783045360_prof);

    }

    // line 7
    public function block_content($context, array $blocks = array())
    {
        $__internal_296623eb1c7292ab8f8a66f8f10bc32e99bd851b912bebf78d147da9905f0f92 = $this->env->getExtension("native_profiler");
        $__internal_296623eb1c7292ab8f8a66f8f10bc32e99bd851b912bebf78d147da9905f0f92->enter($__internal_296623eb1c7292ab8f8a66f8f10bc32e99bd851b912bebf78d147da9905f0f92_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 8
        echo "
\t<section>
\t\t<div class=\"container\">

\t\t";
        // line 12
        if ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashBag", array()), "has", array(0 => "success"), "method")) {
            // line 13
            echo "\t\t\t<div class=\"alert alert-success\">
\t\t\t";
            // line 14
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashBag", array()), "get", array(0 => "success"), "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["msg"]) {
                // line 15
                echo "\t\t\t\t";
                echo twig_escape_filter($this->env, $context["msg"], "html", null, true);
                echo "
\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['msg'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 17
            echo "\t\t\t<div>
\t\t";
        }
        // line 19
        echo "
\t\t";
        // line 20
        if ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashBag", array()), "has", array(0 => "error"), "method")) {
            // line 21
            echo "\t\t\t<div class=\"alert alert-danger\">
\t\t\t";
            // line 22
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashBag", array()), "get", array(0 => "error"), "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["msg"]) {
                // line 23
                echo "\t\t\t\t";
                echo twig_escape_filter($this->env, $context["msg"], "html", null, true);
                echo "
\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['msg'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 25
            echo "\t\t\t<div>
\t\t";
        }
        // line 27
        echo "
\t\t<form method=\"POST\" action=\"";
        // line 28
        echo $this->env->getExtension('routing')->getPath("inscription");
        echo "\">
\t\t\t\t <div class=\"box\">
\t\t\t\t    <div class=\"content\">
\t\t\t\t      <h1>Inscription</h1>
\t\t\t\t      <input class=\"field\" type=\"text\" name=\"name\" placeholder=\"Your name\"><br>
\t\t\t\t      <input class=\"field\" type=\"text\" name=\"email\" placeholder=\"Your Email\"><br>
\t\t\t\t      <input class=\"field\" type=\"password\" name=\"password\" placeholder=\"Your Password\"><br>
\t\t\t\t      <input class=\"btn\" type=\"submit\" value=\"Created\">  
\t\t\t\t    </div>
\t\t\t\t  </div>
\t\t\t</form>

\t\t</div>
\t</section>

";
        
        $__internal_296623eb1c7292ab8f8a66f8f10bc32e99bd851b912bebf78d147da9905f0f92->leave($__internal_296623eb1c7292ab8f8a66f8f10bc32e99bd851b912bebf78d147da9905f0f92_prof);

    }

    public function getTemplateName()
    {
        return "HomeBundle:Default:inscription.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  96 => 28,  93 => 27,  89 => 25,  80 => 23,  76 => 22,  73 => 21,  71 => 20,  68 => 19,  64 => 17,  55 => 15,  51 => 14,  48 => 13,  46 => 12,  40 => 8,  34 => 7,  11 => 3,);
    }
}
/* */
/* */
/* {% extends 'HomeBundle::base.html.twig' %}*/
/* */
/* */
/* */
/* {% block content %}*/
/* */
/* 	<section>*/
/* 		<div class="container">*/
/* */
/* 		{% if app.session.flashBag.has('success') %}*/
/* 			<div class="alert alert-success">*/
/* 			{% for msg in app.session.flashBag.get('success') %}*/
/* 				{{ msg }}*/
/* 			{% endfor %}*/
/* 			<div>*/
/* 		{% endif %}*/
/* */
/* 		{% if app.session.flashBag.has('error') %}*/
/* 			<div class="alert alert-danger">*/
/* 			{% for msg in app.session.flashBag.get('error') %}*/
/* 				{{ msg }}*/
/* 			{% endfor %}*/
/* 			<div>*/
/* 		{% endif %}*/
/* */
/* 		<form method="POST" action="{{ path('inscription') }}">*/
/* 				 <div class="box">*/
/* 				    <div class="content">*/
/* 				      <h1>Inscription</h1>*/
/* 				      <input class="field" type="text" name="name" placeholder="Your name"><br>*/
/* 				      <input class="field" type="text" name="email" placeholder="Your Email"><br>*/
/* 				      <input class="field" type="password" name="password" placeholder="Your Password"><br>*/
/* 				      <input class="btn" type="submit" value="Created">  */
/* 				    </div>*/
/* 				  </div>*/
/* 			</form>*/
/* */
/* 		</div>*/
/* 	</section>*/
/* */
/* {% endblock %}*/
