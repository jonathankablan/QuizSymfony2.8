<?php

/* HomeBundle:Default:noteall.html.twig */
class __TwigTemplate_b8b2a3d8a7ac5b63f9ab1064737acd96b9046992d1a75a44afc3673d259be62c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("HomeBundle::base.html.twig", "HomeBundle:Default:noteall.html.twig", 2);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "HomeBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b009980cec51acb91a7f70a6bf51b293c06c1d3f451fbe9e050333481985abb2 = $this->env->getExtension("native_profiler");
        $__internal_b009980cec51acb91a7f70a6bf51b293c06c1d3f451fbe9e050333481985abb2->enter($__internal_b009980cec51acb91a7f70a6bf51b293c06c1d3f451fbe9e050333481985abb2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "HomeBundle:Default:noteall.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b009980cec51acb91a7f70a6bf51b293c06c1d3f451fbe9e050333481985abb2->leave($__internal_b009980cec51acb91a7f70a6bf51b293c06c1d3f451fbe9e050333481985abb2_prof);

    }

    // line 4
    public function block_content($context, array $blocks = array())
    {
        $__internal_13f499d658a90c45b8c2dcf71f9d0b4190cab58b2bcdff99728feaf61208f98b = $this->env->getExtension("native_profiler");
        $__internal_13f499d658a90c45b8c2dcf71f9d0b4190cab58b2bcdff99728feaf61208f98b->enter($__internal_13f499d658a90c45b8c2dcf71f9d0b4190cab58b2bcdff99728feaf61208f98b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 5
        echo "
\t<section>
\t\t<div class=\"container\">

\t\t\t<header>
\t\t\t\t<h2>Historique de toute les Notes</h2>
\t\t\t</header>

\t\t\t<div class=\"row\">
\t\t\t\t";
        // line 14
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["notes"]) ? $context["notes"] : $this->getContext($context, "notes")));
        foreach ($context['_seq'] as $context["_key"] => $context["note"]) {
            // line 15
            echo "\t\t\t\t\t<div class=\"2u 4u\$(mobile)\">
\t\t\t\t\t\t<article class=\"item\">
\t\t\t\t\t\t\t<header>
\t\t\t\t\t\t\t\t<h3> User </h3> <br />
\t\t\t\t\t\t\t\t<h3> ";
            // line 19
            echo twig_escape_filter($this->env, $this->getAttribute($context["note"], "note", array()), "html", null, true);
            echo " % </h3>
\t\t\t\t\t\t\t</header>
\t\t\t\t\t\t</article>
\t\t\t\t\t</div>
\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['note'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 24
        echo "\t\t\t</div>

\t\t</div>
\t</section>

";
        
        $__internal_13f499d658a90c45b8c2dcf71f9d0b4190cab58b2bcdff99728feaf61208f98b->leave($__internal_13f499d658a90c45b8c2dcf71f9d0b4190cab58b2bcdff99728feaf61208f98b_prof);

    }

    public function getTemplateName()
    {
        return "HomeBundle:Default:noteall.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 24,  61 => 19,  55 => 15,  51 => 14,  40 => 5,  34 => 4,  11 => 2,);
    }
}
/* */
/* {% extends 'HomeBundle::base.html.twig' %}*/
/* */
/* {% block content %}*/
/* */
/* 	<section>*/
/* 		<div class="container">*/
/* */
/* 			<header>*/
/* 				<h2>Historique de toute les Notes</h2>*/
/* 			</header>*/
/* */
/* 			<div class="row">*/
/* 				{% for note in notes %}*/
/* 					<div class="2u 4u$(mobile)">*/
/* 						<article class="item">*/
/* 							<header>*/
/* 								<h3> User </h3> <br />*/
/* 								<h3> {{ note.note }} % </h3>*/
/* 							</header>*/
/* 						</article>*/
/* 					</div>*/
/* 				{% endfor %}*/
/* 			</div>*/
/* */
/* 		</div>*/
/* 	</section>*/
/* */
/* {% endblock %}*/
