<?php

/* HomeBundle:Default:edit.html.twig */
class __TwigTemplate_8a99a73665eb877abd992994d7907958c88e70d90d101bc35c31a526e619e263 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("HomeBundle::base.html.twig", "HomeBundle:Default:edit.html.twig", 2);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "HomeBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1699776e5768ec2af5801154e2d6ab73e1e1023282946508ab19afe37f687cb1 = $this->env->getExtension("native_profiler");
        $__internal_1699776e5768ec2af5801154e2d6ab73e1e1023282946508ab19afe37f687cb1->enter($__internal_1699776e5768ec2af5801154e2d6ab73e1e1023282946508ab19afe37f687cb1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "HomeBundle:Default:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1699776e5768ec2af5801154e2d6ab73e1e1023282946508ab19afe37f687cb1->leave($__internal_1699776e5768ec2af5801154e2d6ab73e1e1023282946508ab19afe37f687cb1_prof);

    }

    // line 4
    public function block_content($context, array $blocks = array())
    {
        $__internal_03053d8d35429759aceb0f4b06ed4736cd998fb61f8a1432393d348832afa1b3 = $this->env->getExtension("native_profiler");
        $__internal_03053d8d35429759aceb0f4b06ed4736cd998fb61f8a1432393d348832afa1b3->enter($__internal_03053d8d35429759aceb0f4b06ed4736cd998fb61f8a1432393d348832afa1b3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 5
        echo "
\t<section>
\t\t<div class=\"container\">

\t\t\t";
        // line 9
        if ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashBag", array()), "has", array(0 => "success"), "method")) {
            // line 10
            echo "\t\t\t<div class=\"alert alert-success\">
\t\t\t";
            // line 11
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashBag", array()), "get", array(0 => "success"), "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["msg"]) {
                // line 12
                echo "\t\t\t\t";
                echo twig_escape_filter($this->env, $context["msg"], "html", null, true);
                echo "
\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['msg'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 14
            echo "\t\t\t<div>
\t\t";
        }
        // line 16
        echo "
\t\t";
        // line 17
        if ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashBag", array()), "has", array(0 => "error"), "method")) {
            // line 18
            echo "\t\t\t<div class=\"alert alert-danger\">
\t\t\t";
            // line 19
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashBag", array()), "get", array(0 => "error"), "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["msg"]) {
                // line 20
                echo "\t\t\t\t";
                echo twig_escape_filter($this->env, $context["msg"], "html", null, true);
                echo "
\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['msg'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 22
            echo "\t\t\t<div>
\t\t";
        }
        // line 24
        echo "
\t\t<form method=\"POST\" action=\"";
        // line 25
        echo $this->env->getExtension('routing')->getPath("profil");
        echo "\">
\t\t\t\t <div class=\"box\">
\t\t\t\t    <div class=\"content\">
\t\t\t\t      <h1>Modification de Profil</h1>
\t\t\t\t      ";
        // line 29
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["profil"]) ? $context["profil"] : $this->getContext($context, "profil")));
        foreach ($context['_seq'] as $context["_key"] => $context["edit"]) {
            // line 30
            echo "\t\t\t\t\t      <input class=\"field\" type=\"text\" name=\"name\" value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["edit"], "name", array()), "html", null, true);
            echo "\"><br>
\t\t\t\t\t      <input class=\"field\" type=\"text\" name=\"email\" value=\"";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute($context["edit"], "email", array()), "html", null, true);
            echo "\"><br>
\t\t\t\t\t      <input class=\"field\" type=\"password\" name=\"password\" value=\"";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute($context["edit"], "password", array()), "html", null, true);
            echo "\"><br>
\t\t\t\t\t   ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['edit'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 34
        echo "\t\t\t\t\t      <input class=\"btn\" type=\"submit\" value=\"Update\">  
\t\t\t\t\t   
\t\t\t\t    </div>
\t\t\t\t  </div>
\t\t\t</form>


\t\t</div>
\t</section>

";
        
        $__internal_03053d8d35429759aceb0f4b06ed4736cd998fb61f8a1432393d348832afa1b3->leave($__internal_03053d8d35429759aceb0f4b06ed4736cd998fb61f8a1432393d348832afa1b3_prof);

    }

    public function getTemplateName()
    {
        return "HomeBundle:Default:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  124 => 34,  116 => 32,  112 => 31,  107 => 30,  103 => 29,  96 => 25,  93 => 24,  89 => 22,  80 => 20,  76 => 19,  73 => 18,  71 => 17,  68 => 16,  64 => 14,  55 => 12,  51 => 11,  48 => 10,  46 => 9,  40 => 5,  34 => 4,  11 => 2,);
    }
}
/* */
/* {% extends 'HomeBundle::base.html.twig' %}*/
/* */
/* {% block content %}*/
/* */
/* 	<section>*/
/* 		<div class="container">*/
/* */
/* 			{% if app.session.flashBag.has('success') %}*/
/* 			<div class="alert alert-success">*/
/* 			{% for msg in app.session.flashBag.get('success') %}*/
/* 				{{ msg }}*/
/* 			{% endfor %}*/
/* 			<div>*/
/* 		{% endif %}*/
/* */
/* 		{% if app.session.flashBag.has('error') %}*/
/* 			<div class="alert alert-danger">*/
/* 			{% for msg in app.session.flashBag.get('error') %}*/
/* 				{{ msg }}*/
/* 			{% endfor %}*/
/* 			<div>*/
/* 		{% endif %}*/
/* */
/* 		<form method="POST" action="{{ path('profil') }}">*/
/* 				 <div class="box">*/
/* 				    <div class="content">*/
/* 				      <h1>Modification de Profil</h1>*/
/* 				      {% for edit in profil %}*/
/* 					      <input class="field" type="text" name="name" value="{{ edit.name }}"><br>*/
/* 					      <input class="field" type="text" name="email" value="{{ edit.email }}"><br>*/
/* 					      <input class="field" type="password" name="password" value="{{ edit.password }}"><br>*/
/* 					   {% endfor %}*/
/* 					      <input class="btn" type="submit" value="Update">  */
/* 					   */
/* 				    </div>*/
/* 				  </div>*/
/* 			</form>*/
/* */
/* */
/* 		</div>*/
/* 	</section>*/
/* */
/* {% endblock %}*/
