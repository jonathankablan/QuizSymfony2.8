-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Dim 19 Juin 2016 à 00:37
-- Version du serveur :  5.7.9
-- Version de PHP :  5.6.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `quiz_home`
--
CREATE DATABASE IF NOT EXISTS `quiz_home` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `quiz_home`;

-- --------------------------------------------------------

--
-- Structure de la table `notes`
--

DROP TABLE IF EXISTS `notes`;
CREATE TABLE IF NOT EXISTS `notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `note` int(11) NOT NULL,
  `iduser` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `idtheme` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `notes`
--

INSERT INTO `notes` (`id`, `note`, `iduser`, `created`, `idtheme`) VALUES
(3, 50, 1, '2016-06-17 18:04:03', 9),
(4, 58, 1, '2016-06-18 14:10:07', 10),
(5, 72, 1, '2016-06-18 14:10:32', 10),
(6, 100, 2, '2016-06-19 01:19:18', 9);

-- --------------------------------------------------------

--
-- Structure de la table `question`
--

DROP TABLE IF EXISTS `question`;
CREATE TABLE IF NOT EXISTS `question` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idtheme` int(11) NOT NULL,
  `question` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `idreponse` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `question`
--

INSERT INTO `question` (`id`, `idtheme`, `question`, `idreponse`) VALUES
(1, 8, 'Html est utilise pour chercher des poulets.', 0),
(2, 8, '<body></body> est utilise en html', 1),
(3, 8, 'un formulaire peut se faire en html', 1),
(4, 9, 'css a été créer par Nicola en 1990', 0),
(6, 9, 'css s''inclure par <style></style>', 1),
(7, 10, 'le javascript peut s''ecrire en Objet.', 1),
(8, 10, '$("class") est utilise en javascript.', 0),
(9, 10, 'le javascript est pareil que le java.', 0),
(10, 10, 'Benzema modriche est l''inventeur du javascript.', 0),
(11, 8, 'le javascript peut s''inclus partout dans le body', 1),
(12, 10, 'le javascript peut s''inclus partout dans le body', 1),
(13, 10, 'on peut faire une connection a la base de donnée en javascript.', 1),
(14, 10, 'NodeJs fonctionne bien avec le javascript.', 1);

-- --------------------------------------------------------

--
-- Structure de la table `theme`
--

DROP TABLE IF EXISTS `theme`;
CREATE TABLE IF NOT EXISTS `theme` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `idauteur` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `theme`
--

INSERT INTO `theme` (`id`, `name`, `idauteur`) VALUES
(8, 'HTML', 0),
(9, 'CSS', 0),
(10, 'Js', 1);

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `password`, `created`) VALUES
(1, 'light', 'kev@gmail.com', '123456', '2016-06-15 17:11:48'),
(2, 'paul', 'paul@gmail.com', '123456', '2016-06-19 01:18:17');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
